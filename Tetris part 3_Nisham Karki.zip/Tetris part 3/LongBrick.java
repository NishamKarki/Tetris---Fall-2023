/**
 * This is a subclass that creates Long brick
 * Nisham Karki
 * Modified Date: 11/18/23
 */

public class LongBrick extends TetrisBrick{
    
    public LongBrick(int wellCenterCol){
        super(wellCenterCol);
        
        color = color.CYAN;
        colorNum = 4;
    }
    
    @Override
    public int[][] initPosition(int wellCenterCol) {
        int[][] brickSegments = {{0, -1}, {0, 0}, {0, 1}, {0, 2}};
        int rowSegment = 0, colSegment = 1;

        for (int brickSeg = 0; brickSeg < numSegments; brickSeg++) {
            position[brickSeg][rowSegment] = 
                    brickSegments[brickSeg][rowSegment];
            position[brickSeg][colSegment] = wellCenterCol 
                    + brickSegments[brickSeg][colSegment];
        }
        
        return position;
    }
    
    @Override
    public void rotate() {
        int rowSegment = 0, colSegment = 1;
        int rotatingSegment = 1;
        
        int centerRow = position[rotatingSegment][rowSegment];
        int centerCol = position[rotatingSegment][colSegment];
        int newRow, newCol;

        for (int brickSeg = 0; brickSeg < numSegments; brickSeg++) {
            if (brickSeg != rotatingSegment) {
                int relativeRow = position[brickSeg][rowSegment] - centerRow;
                int relativeCol = position[brickSeg][colSegment] - centerCol;

                // Rotate 90 degrees clockwise
                newRow = centerRow + relativeCol;
                newCol = centerCol - relativeRow;

                position[brickSeg][rowSegment] = newRow;
                position[brickSeg][colSegment] = newCol;
            }
        }
    }
    
    @Override
    public void unrotate() {
        int rowSegment = 0, colSegment = 1;
        int rotatingSegment = 1;
        
        int centerRow = position[rotatingSegment][rowSegment];
        int centerCol = position[rotatingSegment][colSegment];
        int newRow, newCol;

        for (int brickSeg = 0; brickSeg < numSegments; brickSeg++) {
            if (brickSeg != rotatingSegment) {
                int relativeRow = position[brickSeg][rowSegment] - centerRow;
                int relativeCol = position[brickSeg][colSegment] - centerCol;

                // Rotate 90 degrees clockwise
                newRow = centerRow - relativeCol;
                newCol = centerCol + relativeRow;

                position[brickSeg][rowSegment] = newRow;
                position[brickSeg][colSegment] = newCol;
            }
        }
    }
}
